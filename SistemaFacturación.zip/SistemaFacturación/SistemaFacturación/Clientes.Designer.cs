﻿namespace SistemaFacturación
{
    partial class Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnGuardar = new MetroFramework.Controls.MetroTile();
            this.btnRefresh = new MetroFramework.Controls.MetroTile();
            this.btnBorrar = new MetroFramework.Controls.MetroTile();
            this.btnModificarCliente = new MetroFramework.Controls.MetroTile();
            this.btnAgregar = new MetroFramework.Controls.MetroTile();
            this.cmdClientes = new System.Windows.Forms.DataGridView();
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.razónsocialnombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rNCCédulaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cuentacontableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.cmdClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(642, 79);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(121, 76);
            this.btnGuardar.TabIndex = 11;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(490, 79);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(121, 76);
            this.btnRefresh.TabIndex = 10;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Location = new System.Drawing.Point(335, 79);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(121, 76);
            this.btnBorrar.TabIndex = 9;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnModificarCliente
            // 
            this.btnModificarCliente.Location = new System.Drawing.Point(180, 79);
            this.btnModificarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btnModificarCliente.Name = "btnModificarCliente";
            this.btnModificarCliente.Size = new System.Drawing.Size(121, 76);
            this.btnModificarCliente.TabIndex = 8;
            this.btnModificarCliente.Text = "Modificar";
            this.btnModificarCliente.Click += new System.EventHandler(this.btnModificarCliente_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(24, 79);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(121, 76);
            this.btnAgregar.TabIndex = 7;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // cmdClientes
            // 
            this.cmdClientes.AutoGenerateColumns = false;
            this.cmdClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cmdClientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.razónsocialnombreDataGridViewTextBoxColumn,
            this.rNCCédulaDataGridViewTextBoxColumn,
            this.cuentacontableDataGridViewTextBoxColumn,
            this.estadoDataGridViewTextBoxColumn});
            this.cmdClientes.DataSource = this.clienteBindingSource;
            this.cmdClientes.Location = new System.Drawing.Point(24, 189);
            this.cmdClientes.Name = "cmdClientes";
            this.cmdClientes.RowTemplate.Height = 24;
            this.cmdClientes.Size = new System.Drawing.Size(808, 291);
            this.cmdClientes.TabIndex = 12;
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataSource = typeof(SistemaFacturación.Cliente);
            // 
            // razónsocialnombreDataGridViewTextBoxColumn
            // 
            this.razónsocialnombreDataGridViewTextBoxColumn.DataPropertyName = "Razón_social_nombre";
            this.razónsocialnombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.razónsocialnombreDataGridViewTextBoxColumn.Name = "razónsocialnombreDataGridViewTextBoxColumn";
            this.razónsocialnombreDataGridViewTextBoxColumn.Width = 200;
            // 
            // rNCCédulaDataGridViewTextBoxColumn
            // 
            this.rNCCédulaDataGridViewTextBoxColumn.DataPropertyName = "RNC_Cédula";
            this.rNCCédulaDataGridViewTextBoxColumn.HeaderText = "RNC o Cédula";
            this.rNCCédulaDataGridViewTextBoxColumn.Name = "rNCCédulaDataGridViewTextBoxColumn";
            this.rNCCédulaDataGridViewTextBoxColumn.Width = 180;
            // 
            // cuentacontableDataGridViewTextBoxColumn
            // 
            this.cuentacontableDataGridViewTextBoxColumn.DataPropertyName = "Cuenta_contable";
            this.cuentacontableDataGridViewTextBoxColumn.HeaderText = "Cuenta Contable";
            this.cuentacontableDataGridViewTextBoxColumn.Name = "cuentacontableDataGridViewTextBoxColumn";
            // 
            // estadoDataGridViewTextBoxColumn
            // 
            this.estadoDataGridViewTextBoxColumn.DataPropertyName = "Estado";
            this.estadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoDataGridViewTextBoxColumn.Name = "estadoDataGridViewTextBoxColumn";
            // 
            // Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 516);
            this.Controls.Add(this.cmdClientes);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnModificarCliente);
            this.Controls.Add(this.btnAgregar);
            this.Name = "Clientes";
            this.Text = "Clientes";
            this.Load += new System.EventHandler(this.Clientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cmdClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTile btnGuardar;
        private MetroFramework.Controls.MetroTile btnRefresh;
        private MetroFramework.Controls.MetroTile btnBorrar;
        private MetroFramework.Controls.MetroTile btnModificarCliente;
        private MetroFramework.Controls.MetroTile btnAgregar;
        private System.Windows.Forms.DataGridView cmdClientes;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn razónsocialnombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rNCCédulaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cuentacontableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoDataGridViewTextBoxColumn;
    }
}