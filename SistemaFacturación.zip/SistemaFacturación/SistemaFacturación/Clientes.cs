﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class Clientes : MetroFramework.Forms.MetroForm
    {
        public Clientes()
        {
            InitializeComponent();
        }
        public FacturacionEntities Db { get => db; set => db = value; }
        FacturacionEntities db;


        private void Clientes_Load(object sender, EventArgs e)
        {
            db = new FacturacionEntities();
            clienteBindingSource.DataSource = db.Clientes.ToList();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            clienteBindingSource.DataSource = db.Clientes.ToList();
            Cursor.Current = Cursors.Default;
        }

        private async void btnAgregar_Click(object sender, EventArgs e)
        {
            using (frmMantenimientoCliente frm = new frmMantenimientoCliente(new Cliente() { Estado = false }))
            {
                if (frm.ShowDialog() == DialogResult.OK)
                    try
                    {
                        clienteBindingSource.Add(frm.ClienteInfo);
                        db.Clientes.Add(frm.ClienteInfo);
                        await db.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
            }
        }

        private async void btnModificarCliente_Click(object sender, EventArgs e)
        {
            Cliente obj = clienteBindingSource.Current as Cliente;
            if (obj != null)
            {
                using (frmMantenimientoCliente frm = new frmMantenimientoCliente(obj))
                {
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            clienteBindingSource.EndEdit();
                            await db.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seguro que quiere Borrar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int rows = cmdClientes.RowCount;
                for (int i = rows - 1; i >= 0; i--)
                {
                    if (cmdClientes.Rows[i].Selected)
                    {
                        db.Clientes.Remove(cmdClientes.Rows[i].DataBoundItem as Cliente);
                        clienteBindingSource.RemoveAt(cmdClientes.Rows[i].Index);
                    }
                }
            }
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Seguro que quiere guardar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    clienteBindingSource.EndEdit();
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
           
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=CESARSDELL;Initial Catalog=ProyectoFinalPropietaria;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM Cliente '" + txtBuscar.Text + "% '", sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            cmdClientes.DataSource = dtbl;
            
            
        }
    }
}    

