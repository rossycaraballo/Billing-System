﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmVendedores : MetroFramework.Forms.MetroForm
    {
        public frmVendedores()
        {
            InitializeComponent();
        }

        public FacturacionEntities Db { get => db; set => db = value; }
        FacturacionEntities db;       

        private void Vendedores_Load(object sender, EventArgs e)
        {
            db = new FacturacionEntities();
            vendedorBindingSource.DataSource = db.Vendedors.ToList();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            vendedorBindingSource.DataSource = db.Vendedors.ToList();
            Cursor.Current = Cursors.Default;
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Seguro que quiere guardar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    vendedorBindingSource.EndEdit();
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnAgregar_Click(object sender, EventArgs e)
        {
            using (frmVendedorMantenimiento frm = new frmVendedorMantenimiento(new Vendedor() { Estado = false }))
            {
                if (frm.ShowDialog() == DialogResult.OK)
                    try
                    {
                        vendedorBindingSource.Add(frm.VendedorInfo);
                        db.Vendedors.Add(frm.VendedorInfo);
                        await db.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seguro que quiere Borrar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int rows = cmdVendedores.RowCount;
                for (int i = rows - 1; i >= 0; i--)
                {
                    if (cmdVendedores.Rows[i].Selected)
                    {
                        db.Vendedors.Remove(cmdVendedores.Rows[i].DataBoundItem as Vendedor);
                        vendedorBindingSource.RemoveAt(cmdVendedores.Rows[i].Index);
                    }
                }
            }
        }

        private async void btnModificarCliente_Click(object sender, EventArgs e)
        {
            Vendedor obj = vendedorBindingSource.Current as Vendedor;
            if (obj != null)
            {
                using (frmVendedorMantenimiento frm = new frmVendedorMantenimiento(obj))
                {
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            vendedorBindingSource.EndEdit();
                            await db.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}
