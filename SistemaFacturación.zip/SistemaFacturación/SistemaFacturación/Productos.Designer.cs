﻿namespace SistemaFacturación
{
    partial class frmProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmdProductos = new System.Windows.Forms.DataGridView();
            this.btnGuardar = new MetroFramework.Controls.MetroTile();
            this.btnRefresh = new MetroFramework.Controls.MetroTile();
            this.btnBorrar = new MetroFramework.Controls.MetroTile();
            this.btnModificarCliente = new MetroFramework.Controls.MetroTile();
            this.btnAgregar = new MetroFramework.Controls.MetroTile();
            this.artículosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.descripciónDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costounitarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preciounitarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.cmdProductos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdProductos
            // 
            this.cmdProductos.AutoGenerateColumns = false;
            this.cmdProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cmdProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.descripciónDataGridViewTextBoxColumn,
            this.costounitarioDataGridViewTextBoxColumn,
            this.preciounitarioDataGridViewTextBoxColumn,
            this.estadoDataGridViewTextBoxColumn});
            this.cmdProductos.DataSource = this.artículosBindingSource;
            this.cmdProductos.Location = new System.Drawing.Point(15, 189);
            this.cmdProductos.Name = "cmdProductos";
            this.cmdProductos.RowTemplate.Height = 24;
            this.cmdProductos.Size = new System.Drawing.Size(806, 294);
            this.cmdProductos.TabIndex = 18;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(635, 83);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(121, 76);
            this.btnGuardar.TabIndex = 17;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(483, 83);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(121, 76);
            this.btnRefresh.TabIndex = 16;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Location = new System.Drawing.Point(328, 83);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(121, 76);
            this.btnBorrar.TabIndex = 15;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnModificarCliente
            // 
            this.btnModificarCliente.Location = new System.Drawing.Point(173, 83);
            this.btnModificarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btnModificarCliente.Name = "btnModificarCliente";
            this.btnModificarCliente.Size = new System.Drawing.Size(121, 76);
            this.btnModificarCliente.TabIndex = 14;
            this.btnModificarCliente.Text = "Modificar";
            this.btnModificarCliente.Click += new System.EventHandler(this.btnModificarCliente_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(17, 83);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(121, 76);
            this.btnAgregar.TabIndex = 13;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // artículosBindingSource
            // 
            this.artículosBindingSource.DataSource = typeof(SistemaFacturación.Artículos);
            // 
            // descripciónDataGridViewTextBoxColumn
            // 
            this.descripciónDataGridViewTextBoxColumn.DataPropertyName = "Descripción";
            this.descripciónDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.descripciónDataGridViewTextBoxColumn.Name = "descripciónDataGridViewTextBoxColumn";
            this.descripciónDataGridViewTextBoxColumn.Width = 200;
            // 
            // costounitarioDataGridViewTextBoxColumn
            // 
            this.costounitarioDataGridViewTextBoxColumn.DataPropertyName = "Costo_unitario";
            this.costounitarioDataGridViewTextBoxColumn.HeaderText = "Costo Unitario";
            this.costounitarioDataGridViewTextBoxColumn.Name = "costounitarioDataGridViewTextBoxColumn";
            // 
            // preciounitarioDataGridViewTextBoxColumn
            // 
            this.preciounitarioDataGridViewTextBoxColumn.DataPropertyName = "Precio_unitario";
            this.preciounitarioDataGridViewTextBoxColumn.HeaderText = "Precio Unitario";
            this.preciounitarioDataGridViewTextBoxColumn.Name = "preciounitarioDataGridViewTextBoxColumn";
            // 
            // estadoDataGridViewTextBoxColumn
            // 
            this.estadoDataGridViewTextBoxColumn.DataPropertyName = "Estado";
            this.estadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoDataGridViewTextBoxColumn.Name = "estadoDataGridViewTextBoxColumn";
            // 
            // frmProductos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 524);
            this.Controls.Add(this.cmdProductos);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnModificarCliente);
            this.Controls.Add(this.btnAgregar);
            this.Name = "frmProductos";
            this.Text = "Productos";
            this.Load += new System.EventHandler(this.frmProductos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cmdProductos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView cmdProductos;
        private MetroFramework.Controls.MetroTile btnGuardar;
        private MetroFramework.Controls.MetroTile btnRefresh;
        private MetroFramework.Controls.MetroTile btnBorrar;
        private MetroFramework.Controls.MetroTile btnModificarCliente;
        private MetroFramework.Controls.MetroTile btnAgregar;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripciónDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costounitarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn preciounitarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource artículosBindingSource;
    }
}