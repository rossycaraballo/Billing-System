﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmProductos : MetroFramework.Forms.MetroForm
    {
        public frmProductos()
        {
            InitializeComponent();
        }
        public FacturacionEntities Db { get => db; set => db = value; }
        FacturacionEntities db;        

        private void frmProductos_Load(object sender, EventArgs e)
        {
            db = new FacturacionEntities();
            artículosBindingSource.DataSource = db.Artículos.ToList();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            artículosBindingSource.DataSource = db.Artículos.ToList();
            Cursor.Current = Cursors.Default;
        }

        private async void btnAgregar_Click(object sender, EventArgs e)
        {
            using (frmProductoMantenimiento frm = new frmProductoMantenimiento(new Artículos() { Estado = false }))
            {
                if (frm.ShowDialog() == DialogResult.OK)
                    try
                    {
                        artículosBindingSource.Add(frm.ArticulosInfo);
                        db.Artículos.Add(frm.ArticulosInfo);
                        await db.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
            }
        }

        private async void btnModificarCliente_Click(object sender, EventArgs e)
        {
            Artículos obj = artículosBindingSource.Current as Artículos;
            if (obj != null)
            {
                using (frmProductoMantenimiento frm = new frmProductoMantenimiento(obj))
                {
                    if (frm.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            artículosBindingSource.EndEdit();
                            await db.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seguro que quiere Borrar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int rows = cmdProductos.RowCount;
                for (int i = rows - 1; i >= 0; i--)
                {
                    if (cmdProductos.Rows[i].Selected)
                    {
                        db.Artículos.Remove(cmdProductos.Rows[i].DataBoundItem as Artículos);
                        artículosBindingSource.RemoveAt(cmdProductos.Rows[i].Index);
                    }
                }
            }
        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Seguro que quiere guardar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    artículosBindingSource.EndEdit();
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
