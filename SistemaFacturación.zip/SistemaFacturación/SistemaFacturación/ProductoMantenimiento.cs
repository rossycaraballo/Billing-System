﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmProductoMantenimiento : MetroFramework.Forms.MetroForm
    {
        public frmProductoMantenimiento(Artículos obj)
        {
            InitializeComponent();
            bindingSourceProducto.DataSource = obj;
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        public Artículos ArticulosInfo { get { return bindingSourceProducto.Current as Artículos; } }

        private void ProductoMantenimiento_Load(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bindingSourceProducto.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void checkEstado_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
