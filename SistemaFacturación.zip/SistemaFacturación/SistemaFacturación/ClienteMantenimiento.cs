﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmMantenimientoCliente : MetroFramework.Forms.MetroForm
    {
        public frmMantenimientoCliente(Cliente obj)
        {
            InitializeComponent();
            bindingSourceCliente.DataSource = obj;
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        public Cliente ClienteInfo {get { return bindingSourceCliente.Current as Cliente; } }

        private void frmMantenimientoCliente_Load(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            bindingSourceCliente.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void txtTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void lblTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void chkEstado_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        private void bindingSourceCliente_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void txtDocumento_Click(object sender, EventArgs e)
        {
            if(cbxTipoDocumento = )
            {
                InputStreamReader v_isr = new InputStreamReader(System.in);
                BufferedReader v_br = new BufferedReader(v_isr);
                String v_cadena;
                int a[] = new int[11];
                int b[] = { 1, 2, 1, 2, 1, 2, 1, 2, 1, 2 };
                int c[] = new int[11];

                try
                {
                    System.out.println("Inserte su cédula a validar. Cada vez que inserte un dígito presione enter: ");
                    for (int v_indicador = 0; v_indicador < 11; v_indicador++)
                    {
                        v_cadena = v_br.readLine();
                        a[v_indicador] = Integer.parseInt(v_cadena);
                    }

                    for (int v_indicador = 0; v_indicador < 10; v_indicador++)
                    {
                        c[v_indicador] = a[v_indicador] * b[v_indicador];
                        if (c[v_indicador] > 9)
                        {
                            int primero, segundo, jue;
                            jue = c[v_indicador];

                            segundo = jue % 10;

                            jue = jue / 10;
                            primero = jue % 10;

                            c[v_indicador] = primero + segundo;
                        }
                    }

                    for (int v_indicador = 1; v_indicador < 10; v_indicador++)
                    {
                        c[0] += c[v_indicador];
                    }

                    if (c[0] % 10 != a[10])
                    {
                        int x = c[0] % 10;
                        int y = 10 - x;
                        if (y == a[10])
                            System.out.println("\nLa cédula suministrada ES VÁLIDA.\n");
                else
                    System.out.println("\nLa cédula suministrada NO ES VÁLIDA.\n");
                    }
                    else
                        System.out.println("\nLa cédula suministrada ES VÁLIDA.\n");

                }
                catch (Exception e)
                {
                    System.out.println("\nError!! Problemas con la cédula\n");
                }
            }
            
        }
    }
    }
}
