﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmMantenimientoCliente : MetroFramework.Forms.MetroForm
    {
        public frmMantenimientoCliente(Cliente obj)
        {
            InitializeComponent();
            bindingSourceCliente.DataSource = obj;
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        public Cliente ClienteInfo { get { return bindingSourceCliente.Current as Cliente; } }

        private void frmMantenimientoCliente_Load(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            bindingSourceCliente.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void txtTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void lblTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void chkEstado_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        private void bindingSourceCliente_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDocumento_Click(object sender, EventArgs e)
        {
            
                
        }

        public static bool validaCedula(string txtDocumento)

        {
            int vnTotal = 0;
            string vcCedula = txtDocumento.Replace("-", "");
            int pLongCed = vcCedula.Trim().Length;
            int[] digitoMult = new int[11] { 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1 };

            if (pLongCed < 11 || pLongCed > 11)
                return false;

            for (int vDig = 1; vDig <= pLongCed; vDig++)
            {
                int vCalculo = Int32.Parse(vcCedula.Substring(vDig - 1, 1)) * digitoMult[vDig - 1];
                if (vCalculo < 10)
                    vnTotal += vCalculo;
                else
                    vnTotal += Int32.Parse(vCalculo.ToString().Substring(0, 1)) + Int32.Parse(vCalculo.ToString().Substring(1, 1));
            }

            if (vnTotal % 10 == 0)
                return true;
            else
                return false;
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }
    }
}