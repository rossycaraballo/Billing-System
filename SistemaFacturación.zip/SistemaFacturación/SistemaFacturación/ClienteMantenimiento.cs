﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmMantenimientoCliente : MetroFramework.Forms.MetroForm
    {
        public frmMantenimientoCliente(Cliente obj)
        {
            InitializeComponent();
            bindingSourceCliente.DataSource = obj;
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        public Cliente ClienteInfo {get { return bindingSourceCliente.Current as Cliente; } }

        private void frmMantenimientoCliente_Load(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            bindingSourceCliente.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void txtTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void lblTipoDocumento_Click(object sender, EventArgs e)
        {

        }

        private void chkEstado_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkEstado.CheckState == CheckState.Checked)
                chkEstado.Text = "Activo";
            else if (chkEstado.CheckState == CheckState.Unchecked)
                chkEstado.Text = "Inactivo";
            else
                chkEstado.Text = "???";
        }

        private void bindingSourceCliente_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }
    }
}
