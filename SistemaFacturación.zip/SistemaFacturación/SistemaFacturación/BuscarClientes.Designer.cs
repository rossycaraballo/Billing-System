﻿namespace SistemaFacturación
{
    partial class frmBuscarClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtUsuario = new MetroFramework.Controls.MetroLabel();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.cmdBuscar = new System.Windows.Forms.DataGridView();
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.razónsocialnombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rNCCédulaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cuentacontableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.facturasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reportesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clienteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.cmdBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtUsuario
            // 
            this.txtUsuario.AutoSize = true;
            this.txtUsuario.Location = new System.Drawing.Point(24, 101);
            this.txtUsuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(54, 20);
            this.txtUsuario.TabIndex = 20;
            this.txtUsuario.Text = "Buscar:";
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(103, 101);
            this.txtBuscar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(530, 22);
            this.txtBuscar.TabIndex = 19;
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            this.txtBuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBuscar_KeyPress);
            // 
            // cmdBuscar
            // 
            this.cmdBuscar.AllowUserToAddRows = false;
            this.cmdBuscar.AutoGenerateColumns = false;
            this.cmdBuscar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cmdBuscar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.razónsocialnombreDataGridViewTextBoxColumn,
            this.rNCCédulaDataGridViewTextBoxColumn,
            this.cuentacontableDataGridViewTextBoxColumn,
            this.estadoDataGridViewTextBoxColumn,
            this.facturasDataGridViewTextBoxColumn,
            this.reportesDataGridViewTextBoxColumn});
            this.cmdBuscar.DataSource = this.clienteBindingSource1;
            this.cmdBuscar.Location = new System.Drawing.Point(24, 156);
            this.cmdBuscar.Name = "cmdBuscar";
            this.cmdBuscar.RowTemplate.Height = 24;
            this.cmdBuscar.Size = new System.Drawing.Size(643, 333);
            this.cmdBuscar.TabIndex = 21;
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataSource = typeof(SistemaFacturación.Cliente);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // razónsocialnombreDataGridViewTextBoxColumn
            // 
            this.razónsocialnombreDataGridViewTextBoxColumn.DataPropertyName = "Razón_social_nombre";
            this.razónsocialnombreDataGridViewTextBoxColumn.HeaderText = "Razón_social_nombre";
            this.razónsocialnombreDataGridViewTextBoxColumn.Name = "razónsocialnombreDataGridViewTextBoxColumn";
            // 
            // rNCCédulaDataGridViewTextBoxColumn
            // 
            this.rNCCédulaDataGridViewTextBoxColumn.DataPropertyName = "RNC_Cédula";
            this.rNCCédulaDataGridViewTextBoxColumn.HeaderText = "RNC_Cédula";
            this.rNCCédulaDataGridViewTextBoxColumn.Name = "rNCCédulaDataGridViewTextBoxColumn";
            // 
            // cuentacontableDataGridViewTextBoxColumn
            // 
            this.cuentacontableDataGridViewTextBoxColumn.DataPropertyName = "Cuenta_contable";
            this.cuentacontableDataGridViewTextBoxColumn.HeaderText = "Cuenta_contable";
            this.cuentacontableDataGridViewTextBoxColumn.Name = "cuentacontableDataGridViewTextBoxColumn";
            // 
            // estadoDataGridViewTextBoxColumn
            // 
            this.estadoDataGridViewTextBoxColumn.DataPropertyName = "Estado";
            this.estadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoDataGridViewTextBoxColumn.Name = "estadoDataGridViewTextBoxColumn";
            // 
            // facturasDataGridViewTextBoxColumn
            // 
            this.facturasDataGridViewTextBoxColumn.DataPropertyName = "Facturas";
            this.facturasDataGridViewTextBoxColumn.HeaderText = "Facturas";
            this.facturasDataGridViewTextBoxColumn.Name = "facturasDataGridViewTextBoxColumn";
            // 
            // reportesDataGridViewTextBoxColumn
            // 
            this.reportesDataGridViewTextBoxColumn.DataPropertyName = "Reportes";
            this.reportesDataGridViewTextBoxColumn.HeaderText = "Reportes";
            this.reportesDataGridViewTextBoxColumn.Name = "reportesDataGridViewTextBoxColumn";
            // 
            // clienteBindingSource1
            // 
            this.clienteBindingSource1.DataSource = typeof(SistemaFacturación.Cliente);
            // 
            // frmBuscarClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 545);
            this.Controls.Add(this.cmdBuscar);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.txtBuscar);
            this.Name = "frmBuscarClientes";
            this.Text = "Buscar";
            this.Load += new System.EventHandler(this.BuscarClientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cmdBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel txtUsuario;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.DataGridView cmdBuscar;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn razónsocialnombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rNCCédulaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cuentacontableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn facturasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reportesDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource clienteBindingSource1;
    }
}