﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmAgregarFactura : MetroFramework.Forms.MetroForm
    {
        public frmAgregarFactura()
        {
            InitializeComponent();
        }

        public Factura FacturaInfo { get { return bindingSourceFactura.Current as Factura; } }

        public FacturacionEntities Db { get => db; set => db = value; }
        FacturacionEntities db;
        private void AgregarFactura_Load(object sender, EventArgs e)
        {
            db = new FacturacionEntities();
            bindingSourceFactura.DataSource = db.Facturas.ToList();
            cbxFormaPago.DisplayMember = "Descripción";
            cbxFormaPago.ValueMember = "Descripción";
            using (FacturacionEntities db = new FacturacionEntities())
            {
                cbxFormaPago.DataSource = db.Condiciones_Pago.ToList();
            }

            cbxVendedor.DisplayMember = "Nombre";
            cbxVendedor.ValueMember = "Nombre";
            using (FacturacionEntities db = new FacturacionEntities())
            {
                cbxVendedor.DataSource = db.Vendedors.ToList();
            }

            cbxCliente.DisplayMember = "Nombre";
            cbxCliente.ValueMember = "ID";
            using (FacturacionEntities db = new FacturacionEntities())
            {
                cbxCliente.DataSource = db.Clientes.ToList();
            }

            cbxProducto.DisplayMember = "Nombre";
            cbxProducto.ValueMember = "ID";
            using (FacturacionEntities db = new FacturacionEntities())
            {
                cbxProducto.DataSource = db.Artículos.ToList();
            }
        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void cbxVendedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Seguro que quiere guardar los datos?", "Mensaje", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    bindingSourceFactura.EndEdit();
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
