﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturación
{
    public partial class frmBuscarClientes : MetroFramework.Forms.MetroForm
    {
        public frmBuscarClientes()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable("Cliente");
        private void BuscarClientes_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    using (SqlConnection FacturacionEntities = new SqlConnection(ConfigurationManager.ConnectionStrings["FacturacionEntities"].ConnectionString))
            //    {
            //        if (FacturacionEntities.State == ConnectionState.Closed)
            //            FacturacionEntities.Open();
            //        using(SqlDataAdapter da = new SqlDataAdapter("Select * from cliente", FacturacionEntities))
            //        {
                        
            //            da.Fill(dt);
            //            cmdBuscar.DataSource = dt;
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            
        }

        private void txtBuscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if(e.KeyChar == (char)13)
            //{
            //    DataView dv = dt.DefaultView;
            //    dv.RowFilter = string.Format("cliente like '%{0}%'", txtBuscar.Text);
            //    cmdBuscar.DataSource = dv.ToTable();
            //}
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=CESARSDELL;Initial Catalog=ProyectoFinalPropietaria;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM Cliente '" + txtBuscar.Text + "% '", sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            cmdBuscar.DataSource = dtbl;
        }
    }
}
