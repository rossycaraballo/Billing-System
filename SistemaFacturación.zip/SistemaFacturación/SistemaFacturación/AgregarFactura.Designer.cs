﻿namespace SistemaFacturación
{
    partial class frmAgregarFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.txtDescripcion = new MetroFramework.Controls.MetroTextBox();
            this.txtCantidadDias = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.panelCondicionesPago = new MetroFramework.Controls.MetroPanel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.txtComentario = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.cbxProducto = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.cbxCliente = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cbxVendedor = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cbxFormaPago = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblFecha = new MetroFramework.Controls.MetroLabel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bindingSourceFactura = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSourceCondicionesPago = new System.Windows.Forms.BindingSource(this.components);
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.formapagoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.condicionesPagoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendedorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artículosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cantidadsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comentarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendedorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.condicionesPagoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.artículosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vendedorBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clienteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.artículosBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panelCondicionesPago.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceFactura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCondicionesPago)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendedorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.condicionesPagoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendedorBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTile1
            // 
            this.metroTile1.Location = new System.Drawing.Point(8, 6);
            this.metroTile1.Margin = new System.Windows.Forms.Padding(4);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(435, 73);
            this.metroTile1.TabIndex = 29;
            this.metroTile1.Text = "Condiciones de Pagos";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceCondicionesPago, "Descripción", true));
            this.txtDescripcion.Location = new System.Drawing.Point(165, 161);
            this.txtDescripcion.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(277, 28);
            this.txtDescripcion.TabIndex = 28;
            // 
            // txtCantidadDias
            // 
            this.txtCantidadDias.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceCondicionesPago, "Cantidad_dias", true));
            this.txtCantidadDias.Location = new System.Drawing.Point(165, 106);
            this.txtCantidadDias.Margin = new System.Windows.Forms.Padding(4);
            this.txtCantidadDias.Name = "txtCantidadDias";
            this.txtCantidadDias.Size = new System.Drawing.Size(277, 28);
            this.txtCantidadDias.TabIndex = 26;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(8, 107);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(114, 20);
            this.metroLabel7.TabIndex = 25;
            this.metroLabel7.Text = "Cantidad de dias:";
            // 
            // panelCondicionesPago
            // 
            this.panelCondicionesPago.Controls.Add(this.metroTile1);
            this.panelCondicionesPago.Controls.Add(this.txtDescripcion);
            this.panelCondicionesPago.Controls.Add(this.metroLabel8);
            this.panelCondicionesPago.Controls.Add(this.txtCantidadDias);
            this.panelCondicionesPago.Controls.Add(this.metroLabel7);
            this.panelCondicionesPago.HorizontalScrollbarBarColor = true;
            this.panelCondicionesPago.HorizontalScrollbarHighlightOnWheel = false;
            this.panelCondicionesPago.HorizontalScrollbarSize = 12;
            this.panelCondicionesPago.Location = new System.Drawing.Point(543, 81);
            this.panelCondicionesPago.Margin = new System.Windows.Forms.Padding(4);
            this.panelCondicionesPago.Name = "panelCondicionesPago";
            this.panelCondicionesPago.Size = new System.Drawing.Size(461, 221);
            this.panelCondicionesPago.TabIndex = 37;
            this.panelCondicionesPago.VerticalScrollbarBarColor = true;
            this.panelCondicionesPago.VerticalScrollbarHighlightOnWheel = false;
            this.panelCondicionesPago.VerticalScrollbarSize = 13;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(8, 162);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(85, 20);
            this.metroLabel8.TabIndex = 27;
            this.metroLabel8.Text = "Descripcion:";
            // 
            // txtComentario
            // 
            this.txtComentario.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceFactura, "Comentario", true));
            this.txtComentario.Location = new System.Drawing.Point(221, 548);
            this.txtComentario.Margin = new System.Windows.Forms.Padding(4);
            this.txtComentario.Name = "txtComentario";
            this.txtComentario.Size = new System.Drawing.Size(291, 28);
            this.txtComentario.TabIndex = 36;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(61, 685);
            this.metroButton1.Margin = new System.Windows.Forms.Padding(4);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(160, 54);
            this.metroButton1.TabIndex = 35;
            this.metroButton1.Text = "Cancelar";
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(844, 685);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(160, 54);
            this.btnSave.TabIndex = 34;
            this.btnSave.Text = "Guardar";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cbxProducto
            // 
            this.cbxProducto.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindingSourceFactura, "Artículos", true));
            this.cbxProducto.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.artículosBindingSource, "Descripción", true));
            this.cbxProducto.DataSource = this.artículosBindingSource;
            this.cbxProducto.DisplayMember = "Descripción";
            this.cbxProducto.FormattingEnabled = true;
            this.cbxProducto.ItemHeight = 24;
            this.cbxProducto.Location = new System.Drawing.Point(190, 261);
            this.cbxProducto.Margin = new System.Windows.Forms.Padding(4);
            this.cbxProducto.Name = "cbxProducto";
            this.cbxProducto.Size = new System.Drawing.Size(276, 30);
            this.cbxProducto.Style = MetroFramework.MetroColorStyle.Blue;
            this.cbxProducto.TabIndex = 33;
            this.cbxProducto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbxProducto.ValueMember = "Descripción";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(37, 261);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(68, 20);
            this.metroLabel5.TabIndex = 32;
            this.metroLabel5.Text = "Producto:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(53, 548);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(84, 20);
            this.metroLabel4.TabIndex = 31;
            this.metroLabel4.Text = "Comentario:";
            // 
            // cbxCliente
            // 
            this.cbxCliente.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindingSourceFactura, "Cliente", true));
            this.cbxCliente.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.clienteBindingSource, "Razón_social_nombre", true));
            this.cbxCliente.DataSource = this.clienteBindingSource;
            this.cbxCliente.DisplayMember = "Razón_social_nombre";
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.ItemHeight = 24;
            this.cbxCliente.Location = new System.Drawing.Point(190, 206);
            this.cbxCliente.Margin = new System.Windows.Forms.Padding(4);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(276, 30);
            this.cbxCliente.Style = MetroFramework.MetroColorStyle.Blue;
            this.cbxCliente.TabIndex = 30;
            this.cbxCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbxCliente.ValueMember = "Razón_social_nombre";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(37, 206);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(55, 20);
            this.metroLabel2.TabIndex = 29;
            this.metroLabel2.Text = "Cliente:";
            // 
            // cbxVendedor
            // 
            this.cbxVendedor.DataBindings.Add(new System.Windows.Forms.Binding("SelectedItem", this.bindingSourceFactura, "Vendedor", true));
            this.cbxVendedor.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.vendedorBindingSource, "Nombre", true));
            this.cbxVendedor.DataSource = this.vendedorBindingSource;
            this.cbxVendedor.DisplayMember = "Nombre";
            this.cbxVendedor.FormattingEnabled = true;
            this.cbxVendedor.ItemHeight = 24;
            this.cbxVendedor.Location = new System.Drawing.Point(190, 154);
            this.cbxVendedor.Margin = new System.Windows.Forms.Padding(4);
            this.cbxVendedor.Name = "cbxVendedor";
            this.cbxVendedor.Size = new System.Drawing.Size(276, 30);
            this.cbxVendedor.Style = MetroFramework.MetroColorStyle.Blue;
            this.cbxVendedor.TabIndex = 28;
            this.cbxVendedor.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbxVendedor.ValueMember = "Nombre";
            this.cbxVendedor.SelectedIndexChanged += new System.EventHandler(this.cbxVendedor_SelectedIndexChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(37, 154);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(74, 20);
            this.metroLabel1.TabIndex = 27;
            this.metroLabel1.Text = "Vendedor:";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // cbxFormaPago
            // 
            this.cbxFormaPago.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bindingSourceCondicionesPago, "Descripción", true));
            this.cbxFormaPago.DataSource = this.bindingSourceCondicionesPago;
            this.cbxFormaPago.DisplayMember = "Descripción";
            this.cbxFormaPago.FormattingEnabled = true;
            this.cbxFormaPago.ItemHeight = 24;
            this.cbxFormaPago.Location = new System.Drawing.Point(190, 99);
            this.cbxFormaPago.Margin = new System.Windows.Forms.Padding(4);
            this.cbxFormaPago.Name = "cbxFormaPago";
            this.cbxFormaPago.Size = new System.Drawing.Size(276, 30);
            this.cbxFormaPago.Style = MetroFramework.MetroColorStyle.Blue;
            this.cbxFormaPago.TabIndex = 26;
            this.cbxFormaPago.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbxFormaPago.ValueMember = "Descripción";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(37, 99);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(105, 20);
            this.metroLabel3.TabIndex = 25;
            this.metroLabel3.Text = "Forma de Pago:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.fechaDataGridViewTextBoxColumn,
            this.formapagoDataGridViewTextBoxColumn,
            this.condicionesPagoDataGridViewTextBoxColumn,
            this.clienteDataGridViewTextBoxColumn,
            this.vendedorDataGridViewTextBoxColumn,
            this.artículosDataGridViewTextBoxColumn,
            this.cantidadsDataGridViewTextBoxColumn,
            this.comentarioDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bindingSourceFactura;
            this.dataGridView1.Location = new System.Drawing.Point(37, 335);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(968, 177);
            this.dataGridView1.TabIndex = 38;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(53, 604);
            this.lblFecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(49, 20);
            this.lblFecha.TabIndex = 39;
            this.lblFecha.Text = "Fecha:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(221, 601);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(261, 22);
            this.dateTimePicker1.TabIndex = 40;
            // 
            // bindingSourceFactura
            // 
            this.bindingSourceFactura.DataSource = typeof(SistemaFacturación.Factura);
            // 
            // bindingSourceCondicionesPago
            // 
            this.bindingSourceCondicionesPago.DataSource = typeof(SistemaFacturación.Condiciones_Pago);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Width = 50;
            // 
            // fechaDataGridViewTextBoxColumn
            // 
            this.fechaDataGridViewTextBoxColumn.DataPropertyName = "Fecha";
            this.fechaDataGridViewTextBoxColumn.HeaderText = "Fecha";
            this.fechaDataGridViewTextBoxColumn.Name = "fechaDataGridViewTextBoxColumn";
            // 
            // formapagoDataGridViewTextBoxColumn
            // 
            this.formapagoDataGridViewTextBoxColumn.DataPropertyName = "Forma_pago";
            this.formapagoDataGridViewTextBoxColumn.HeaderText = "Forma de pago";
            this.formapagoDataGridViewTextBoxColumn.Name = "formapagoDataGridViewTextBoxColumn";
            // 
            // condicionesPagoDataGridViewTextBoxColumn
            // 
            this.condicionesPagoDataGridViewTextBoxColumn.DataPropertyName = "Condiciones_Pago";
            this.condicionesPagoDataGridViewTextBoxColumn.HeaderText = "Condiciones del pago";
            this.condicionesPagoDataGridViewTextBoxColumn.Name = "condicionesPagoDataGridViewTextBoxColumn";
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            this.clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            this.clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            this.clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            this.clienteDataGridViewTextBoxColumn.Width = 150;
            // 
            // vendedorDataGridViewTextBoxColumn
            // 
            this.vendedorDataGridViewTextBoxColumn.DataPropertyName = "Vendedor";
            this.vendedorDataGridViewTextBoxColumn.HeaderText = "Vendedor";
            this.vendedorDataGridViewTextBoxColumn.Name = "vendedorDataGridViewTextBoxColumn";
            this.vendedorDataGridViewTextBoxColumn.Width = 150;
            // 
            // artículosDataGridViewTextBoxColumn
            // 
            this.artículosDataGridViewTextBoxColumn.DataPropertyName = "Artículos";
            this.artículosDataGridViewTextBoxColumn.HeaderText = "Artículos";
            this.artículosDataGridViewTextBoxColumn.Name = "artículosDataGridViewTextBoxColumn";
            // 
            // cantidadsDataGridViewTextBoxColumn
            // 
            this.cantidadsDataGridViewTextBoxColumn.DataPropertyName = "Cantidads";
            this.cantidadsDataGridViewTextBoxColumn.HeaderText = "Cantidads";
            this.cantidadsDataGridViewTextBoxColumn.Name = "cantidadsDataGridViewTextBoxColumn";
            // 
            // comentarioDataGridViewTextBoxColumn
            // 
            this.comentarioDataGridViewTextBoxColumn.DataPropertyName = "Comentario";
            this.comentarioDataGridViewTextBoxColumn.HeaderText = "Comentario";
            this.comentarioDataGridViewTextBoxColumn.Name = "comentarioDataGridViewTextBoxColumn";
            this.comentarioDataGridViewTextBoxColumn.Width = 300;
            // 
            // vendedorBindingSource
            // 
            this.vendedorBindingSource.DataSource = typeof(SistemaFacturación.Vendedor);
            // 
            // condicionesPagoBindingSource
            // 
            this.condicionesPagoBindingSource.DataSource = typeof(SistemaFacturación.Condiciones_Pago);
            // 
            // clienteBindingSource
            // 
            this.clienteBindingSource.DataSource = typeof(SistemaFacturación.Cliente);
            // 
            // artículosBindingSource
            // 
            this.artículosBindingSource.DataSource = typeof(SistemaFacturación.Artículos);
            // 
            // vendedorBindingSource1
            // 
            this.vendedorBindingSource1.DataSource = typeof(SistemaFacturación.Vendedor);
            // 
            // clienteBindingSource1
            // 
            this.clienteBindingSource1.DataSource = typeof(SistemaFacturación.Cliente);
            // 
            // artículosBindingSource1
            // 
            this.artículosBindingSource1.DataSource = typeof(SistemaFacturación.Artículos);
            // 
            // frmAgregarFactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 783);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panelCondicionesPago);
            this.Controls.Add(this.txtComentario);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbxProducto);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.cbxCliente);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.cbxVendedor);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.cbxFormaPago);
            this.Controls.Add(this.metroLabel3);
            this.Name = "frmAgregarFactura";
            this.Text = "Factura";
            this.Load += new System.EventHandler(this.AgregarFactura_Load);
            this.panelCondicionesPago.ResumeLayout(false);
            this.panelCondicionesPago.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceFactura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCondicionesPago)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendedorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.condicionesPagoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendedorBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.artículosBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroTextBox txtDescripcion;
        private MetroFramework.Controls.MetroTextBox txtCantidadDias;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroPanel panelCondicionesPago;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox txtComentario;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroComboBox cbxProducto;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroComboBox cbxCliente;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cbxVendedor;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroComboBox cbxFormaPago;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroLabel lblFecha;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.BindingSource bindingSourceCondicionesPago;
        private System.Windows.Forms.BindingSource bindingSourceFactura;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn formapagoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn condicionesPagoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendedorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn artículosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cantidadsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn comentarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource artículosBindingSource;
        private System.Windows.Forms.BindingSource clienteBindingSource;
        private System.Windows.Forms.BindingSource vendedorBindingSource;
        private System.Windows.Forms.BindingSource condicionesPagoBindingSource;
        private System.Windows.Forms.BindingSource artículosBindingSource1;
        private System.Windows.Forms.BindingSource clienteBindingSource1;
        private System.Windows.Forms.BindingSource vendedorBindingSource1;
    }
}